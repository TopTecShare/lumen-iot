<h1>Hi, {{ $name }}</h1>
<a href="{{ $token }}">Press here to reset password.</a>