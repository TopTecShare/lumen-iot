<html>
<head>
    <title>CNAM</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="container">
AAA
<table class="table">
    <thead>
    <th>UUID</th>
    <th>Ile raportów</th>
    <th>Kiedy ostatni</th>
    <th>SensorID</th>
    </thead>
    <tbody>
    <?php $__currentLoopData = $sensors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cnt => $sensor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cnt); ?></td>
            <td><a href="/sensors/<?php echo e($sensor->uuid); ?>"><?php echo e($sensor->uuid); ?></a></td>
            <td><?php echo e($sensor->rawDatapoints()->count()); ?></td>
            <td><?php if($sensor->rawDatapoints()->count() > 0): ?>
                    <?php echo e(time_elapsed_string($sensor->rawDatapoints()->orderBy('created_at', 'desc')->first()->created_at)); ?>

                <?php endif; ?>


            </td>
            <td><?php echo e($sensor->sensor_number); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>

</table>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH C:\Users\Tiger\3D Objects\lumen\CNAM\resources\views/sensors.blade.php ENDPATH**/ ?>