<html>
    <head>
        <title>CNAM</title>
        <link
            rel="stylesheet"
            href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
        />
        <link
            rel="stylesheet"
            href="//cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css"
        />
    </head>
    <style>
        body {
            word-break: break-word;
        }
        .right {
            float: right;
            margin-right: 10%;
        }
    </style>

    <body class="container">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <span style="font-weight: bold; font-size: 1.5em"> Nickname: </span
        ><?php echo e($sensor->nickname); ?>


        <a class="right"
            ><form action="/sensors" accept-charset="UTF-8" method="post">
                <input
                    type="hidden"
                    class="form-control"
                    name="uuid"
                    value="<?php echo e($sensor->uuid); ?>"
                />
                <?php if($dashboard): ?>
                <input
                    type="submit"
                    class="btn btn-success"
                    value="Remove From Dashboard"
                />
                <input type="hidden" name="_method" value="DELETE" />
                <?php else: ?>
                <input
                    type="submit"
                    class="btn btn-success"
                    value="Add To Dashboard"
                />
                <?php endif; ?>
            </form></a
        >
        <a class="btn btn-success right" data-toggle="modal" href="#nickname">
            <?php if($sensor->nickname == ""): ?> <span>Add </span> <?php else: ?>
            <span>Edit </span> <?php endif; ?> Nickname
        </a>

        <table class="table datatable">
            <thead>
                <tr>
                    <th>Json</th>
                    <th>Created at</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $json; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(print_r($dp->json, true)); ?></td>
                    <td><?php echo e($dp->created_at->setTimeZone($tz)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <div class="pagination">
            <?php echo e($json->links('pagination::bootstrap-4')); ?>

        </div>
        <div id="nickname" class="modal fade">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form
                        action="/sensors"
                        accept-charset="UTF-8"
                        method="post"
                    >
                        <input type="hidden" name="_method" value="PUT" />
                        <div class="modal-header">
                            <h4 class="modal-title">Nickname</h4>
                            <button
                                type="button"
                                class="close"
                                data-dismiss="modal"
                                aria-hidden="true"
                            >
                                &times;
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Nickname</label>
                                <input
                                    type="text"
                                    class="form-control"
                                    name="nickname"
                                    value="<?php echo e($sensor->nickname); ?>"
                                />
                                <input
                                    type="hidden"
                                    class="form-control"
                                    name="uuid"
                                    value="<?php echo e($sensor->uuid); ?>"
                                />
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input
                                type="button"
                                class="btn btn-default"
                                data-dismiss="modal"
                                value="Cancel"
                            />
                            <input
                                type="submit"
                                class="btn btn-success"
                                value="Confirm"
                            />
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="//cdn.datatables.net/1.11.3/js/jquery.dataTables.min.js"></script>
        <script>
            $(document).ready(function () {
                $(".datatable").DataTable({
                    language: {
                        sProcessing: "Przetwarzanie...",
                        sLengthMenu: "Pokaż _MENU_ pozycji",
                        sZeroRecords: "Nie znaleziono pasujących pozycji",
                        sInfoThousands: " ",
                        sInfo: "Pozycje od _START_ do _END_ z _TOTAL_ łącznie",
                        sInfoEmpty: "Pozycji 0 z 0 dostępnych",
                        sInfoFiltered:
                            "(filtrowanie spośród _MAX_ dostępnych pozycji)",
                        sInfoPostFix: "",
                        sSearch: "Szukaj:",
                        sUrl: "",
                        oPaginate: {
                            sFirst: "Pierwsza",
                            sPrevious: "Poprzednia",
                            sNext: "Następna",
                            sLast: "Ostatnia",
                        },
                        sEmptyTable: "Brak danych",
                        sLoadingRecords: "Wczytywanie...",
                        oAria: {
                            sSortAscending:
                                ": aktywuj, by posortować kolumnę rosnąco",
                            sSortDescending:
                                ": aktywuj, by posortować kolumnę malejąco",
                        },
                    },
                });
                $('[data-toggle="tooltip"]').tooltip();
            });
        </script>
    </body>
</html>
<?php /**PATH C:\work\lumen\CNAM\resources\views/sensor.blade.php ENDPATH**/ ?>