<h1>Hi, <?php echo e($name); ?></h1>
<a href="<?php echo e($token); ?>">Press here to reset password.</a><?php /**PATH C:\work\lumen\CNAM\resources\views/mail.blade.php ENDPATH**/ ?>